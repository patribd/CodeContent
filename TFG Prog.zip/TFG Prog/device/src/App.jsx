import './App.css'
import React, { useEffect, useState } from 'react';

const CODES = {
  USUARIO_REGISTRADO: 0,
  USUARIO_ALIAS: 1,
  RESULTADO_INTENTO: 3,
  SCOREBOARD: 5,
  PALABRA_INVALIDA: 7
}

let arrayData = [null, null, null, null, null, null];   // WE WILL HAVE TO CHANGE IT WITH THE DATA WE WILL OBTAIN FROM THE PACKAGES
let deviceData = [];
let packageData = [];
let currentData = [];

switch (arrayData.length){
  case 1:
    // We are obtaining the data related to the new device
    deviceData = arrayData;
    break;
  case 4:
    // We are obtaining the data related to the current measurement
    currentData = arrayData;
    break;
  case 6:
     // We are obtaining the data related to the package
     packageData = arrayData;
    break;
}

function App() {
  const [ws, setWs] = useState(null);
  const [deviceGetId, setDeviceGetId] = useState(null);
  const [deviceDeleteId, setDeviceDeleteId] = useState(null);
  const [packageGetId, setPackageGetId] = useState(null);
  const [packageDeleteId, setPackageDeleteId] = useState(null);
  const [currentGetId, setCurrentGetId] = useState(null);
  const [currentDeleteId, setCurrentDeleteId] = useState(null);


  useEffect(() => {
    const ws2 = new WebSocket('ws://localhost:8080');
    setWs(ws2);

    ws2.onmessage = (event) => {
      const json = JSON.parse(event.data);
      try {
        setMessage(json.mensaje);
        
      } catch (err) {
        console.log(err);
      }
      
    };

    return () => {
      ws.close();
    }
  }, []);

  const devicePost = () => {
    // We will send the information related to a device, the server will check if that device is already in the database
    const json = {
      'type': '00',
      'deviceId' : deviceData[0],
      'deviceName' : deviceData[1]
    };
    ws.send(JSON.stringify(json));
  }

  const packagePost = () => {
    // We will send information related to a package
    const json = {
      'type' : '10',
      'packageId': packageData[0],
      'deviceSource' : packageData[1], 
      'deviceDestination' : packageData[2],
      'timestamp' : packageData[3]
    };
    ws.send(JSON.stringify(json));
  }

  const currentPost = () => {
    // We will send information related to the current measured
    const json = {
      'type' : '20',
      'currentId' : currentData[0],
      'deviceSource' : currentData[1],
      'value' : currentData[2],
      'timestamp' : currentData[3],
      'measurement' : currentData[4]
    };
    ws.send(JSON.stringify(json));
  }

  const deviceGet = () => {
    const json = {
      'type' : '01',
      'deviceId' : deviceGetId
    };
    ws.send(JSON.stringify(json));
  }

  const packageGet = () => {
    const json = {
      'type' : '11',
      'packageId' : packageGetId
    };
    ws.send(JSON.stringify(json));
  }

  const currentGet = () => {
    const json = {
      'type' : '21',
      'currentId' : currentGetId
    };
    ws.send(JSON.stringify(json));
  }

  const deviceDelete = () => {
    const json = {
      'type' : '02',
      'deviceId' : deviceDeleteId
    };
    ws.send(JSON.stringify(json));
  }

  const packageDelete = () => {
    const json = {
      'type' : '12',
      'packageId' : packageDeleteId
    };
    ws.send(JSON.stringify(json));
  }

  const currentDelete = () => {
    const json = {
      'type' : '22',
      'currentId' : currentDeleteId
    };
    ws.send(JSON.stringify(json));
  }

  
  const handleDeviceGet = (event) => {
    setDeviceGetId(event.target.value);
  }
  
  const handleDeviceDelete = (event) => {
    setDeviceDeleteId(event.target.value);
  }

  const handlePackageGet = (event) => {
    setPackageGetId(event.target.value);
  }

  const handlePackageDelete = (event) => {
    setPackageDeleteId(event.target.value);
  }

  const handleCurrentGet = (event) => {
    setCurrentGetId(event.target.value);
  }

  const handleCurrentDelete = (event) => {
    setCurrentDeleteId(event.target.value);
  }

  return(
    <>
    <div id='cabecera'>
      <button onClick={devicePost}>Register a device</button>
      <input type="text" placeholder="Introduce the id..." value={username} onChange={handleDeviceGet}></input><button onClick={deviceGet}>Obtain information of a device.</button>
      <input type="text" placeholder="Introduce the id..." value={username} onChange={handleDeviceDelete}></input><button onClick={deviceDelete}>Delete a device from the database.</button>

      <button onClick={packagePost}>Register a package</button>
      <input type="text" placeholder="Introduce the id..." value={username} onChange={handlePackageGet}></input><button onClick={packageGet}>Obtain information of a package.</button>
      <input type="text" placeholder="Introduce the id..." value={username} onChange={handlePackageDelete}></input><button onClick={packageDelete}>Delete a package from the database.</button>

      <button onClick={currentPost}>Register a current measurement</button>
      <input type="text" placeholder="Introduce the id..." value={username} onChange={handleCurrentGet}></input><button onClick={currentGet}>Obtain information of a measurement</button>
      <input type="text" placeholder="Introduce the id..." value={username} onChange={handleCurrentDelete}></input><button onClick={currentDelete}>Delete a measurement from the database</button>
    </div>
    </>
  )
}

export default App