<?php

include("functions.php");

// Variables initiation
$db=initiateMySQL();


// Obtain the data that will be sent to the database
$data = explode("," ,$argv[1]);

// Depending on the type of data received we will do a specific query

switch ($data[0]){

    case 'tx':
        // It is necessary to send that package to the txPackages

        $package = $db -> prepare("INSERT INTO txPackages (deviceSourceID, deviceDestinationID, packageID, floatTimestamp, dateTimestamp) VALUES (:deviceSourceID, :deviceDestinationID, :packageID, :floatTimestamp, :dateTimestamp)");
        unset($content);
        //$content['deviceSourceID'] = getID($data[2]);
        //$content['deviceDestinationID'] = getID($data['3']);
        $content['deviceSourceID'] = intval($data[1]);
        $content['deviceDestinationID'] = intval($data['2']);
        $content['packageID'] = $data['3'];
        //$content['floatTimestamp'] = $data['0'];
        $content['floatTimestamp'] = 17111014284.060658;
        
        try {
            //$dateTime = floatToDatetime($data[0]);
            $dateTime = floatToDatetime(17111014284.060658);
            $content['dateTimestamp']= $dateTime->format('Y-m-d H:i:s.u'); 
        } catch (Exception $e) {
            $content['dateTimestamp'] = 'Error: ' . $e->getMessage();
        }

        $p1 = $package -> execute($content);
        $p2 = $package -> fetch();

        if ($p2 != null){
            // There has been an error trying to introduce the data to the Database

            // -------------------------------------------------------------------------------------------------------
            print("There has been an error sending the data to the 'txPackages' table.");
        }
        

        break;

    case 'rx':
        // It is necessary to send that package to the rxPackages

        $package = $db -> prepare("INSERT INTO rxPackages (deviceSourceID, deviceDestinationID, packageID, floatTimestamp, dateTimestamp) VALUES (:deviceSourceID, :deviceDestinationID, :packageID, :floatTimestamp, :dateTimestamp)");
        unset($content);
        //$content['deviceSourceID'] = getID($data[1]);
        //$content['deviceDestinationID'] = getID($data['2']);
        $content['deviceSourceID'] = intval($data[1]);
        $content['deviceDestinationID'] = intval($data['2']);
        $content['packageID'] = $data['3'];
        //$content['floatTimestamp'] = $data['0'];
        $content['floatTimestamp'] = 17111014284.060658;
        
        try {
            //$dateTime = floatToDatetime($data[0]);
            $dateTime = floatToDatetime(17111014284.060658);
            $content['dateTimestamp']= $dateTime->format('Y-m-d H:i:s.u'); 
        } catch (Exception $e) {
            $content['dateTimestamp'] = 'Error: ' . $e->getMessage();
        }

        $p1 = $package -> execute($content);
        $p2 = $package -> fetch();

        if ($p2 != null){
            // There has been an error trying to introduce the data to the Database

            // -------------------------------------------------------------------------------------------------------
            print("There has been an error sending the data to the 'rxPackages' table.");
        }
        
        
        break;

    case 'R':
        // It is necessary to send that package to the routings

        $package = $db -> prepare ("INSERT INTO routings (floatTimestamp, dateTimestamp, deviceID, parentID) VALUES (:floatTimestamp, :dateTimestamp, :deviceID, :parentID)");
        unset($content);
        //$content['floatTimestamp'] = $data[3];
        $content['floatTimestamp'] = 17111014284.060658;
        try {
            //$dateTime = floatToDatetime($data[0]);
            $dateTime = floatToDatetime(17111014284.060658);
            $content['dateTimestamp']= $dateTime->format('Y-m-d H:i:s.u'); 
        } catch (Exception $e) {
            $content['dateTimestamp'] = 'Error: ' . $e->getMessage();
        }
        //$content['deviceID'] = getID($data[1]);
        //$content['parentID'] = getID($data[2]);
        $content['deviceID'] = intval($data[1]);
        $content['parentID'] = intval($data[2]);

        $p1 = $package -> execute($content);
        $p2 = $package -> fetch();

        if ($p2 != null){
            // There has been an error trying to introduce the data to the Database

            // -------------------------------------------------------------------------------------------------------
            print("There has been an error sending the data to the 'routings' table.");
        }

        break;
    
    case 'I':
        // It is necessary to send that package to the currents

        $package = $db -> prepare ("INSERT INTO currents (deviceSourceID, value, floatTimestamp, dateTimestamp, measurement) VALUES (:deviceSourceID, :value, :floatTimestamp, :dateTimestamp, :measurement)");
        unset($content);
        //$content['deviceSourceID'] = getID($data[2]);
        $content['deviceSourceID'] = intval($data[2]);
        $content['value'] = $data[3];
        $content['floatTimestamp'] = $data[0];
        try {
            $dateTime = floatToDatetime($data[0]);
            $content['dateTimestamp']= $dateTime->format('Y-m-d H:i:s.u'); 
        } catch (Exception $e) {
            $content['dateTimestamp'] = 'Error: ' . $e->getMessage();
        }
        $content['measurement'] = $data[4];

        $p1 = $package -> execute($content);
        $p2 = $package -> fetch();

        if ($p2 != null){
            // There has been an error trying to introduce the data to the Database

            // -------------------------------------------------------------------------------------------------------
            print("There has been an error sending the data to the 'currents' table.");
        }

        break;
}














?>