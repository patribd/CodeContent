<?php
include("functions.php");

$db = initiateMySQL();

$device = $argv[1];

$deviceID = $db -> prepare ("SELECT id FROM devices WHERE deviceName =:deviceName");
unset($content);
$content['deviceName'] = strval($device);

$p1 = $deviceID -> execute($content);
$p2 = $deviceID -> fetch();

if ($p2 == null){
    // The device is not in the database, we have to introduce it
    $deviceID = $db -> prepare ("INSERT INTO devices  (deviceName) values (:deviceName)");
    unset($content);
    $content['deviceName'] = strval($device);

    $p1 = $deviceID -> execute($content);
    $p2 = $deviceID -> fetch();

    if ($p2 != null){
        // There has been some problem while introducing the device in the database
    }else{
        print("The device has been correctly registered.");
    }
}else{
    print("The device is already registered in the database. Thank you.");
}




?>