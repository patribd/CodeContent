<?php

function initiateMySQL(){
    //new PDO(description,user,password);
    $dbdescr="mysql:host=localhost; dbname=sysMonitorDB; port=3306";
    $cnx= new PDO($dbdescr, "root" , "lalala2023.LALALA" );

    return $cnx;
}

function floatToDatetime($floatValue) {
    // Converts the float value to seconds from the Unix period
    $seconds = (int)$floatValue;
    
    // Convert the float microseconds (decimal part) to real microseconds
    $microseconds = ($floatValue - $seconds) * 1000000;
    
    // Create an object called Datetime from the seconds and microseconds
    $dateTime = DateTime::createFromFormat('U.u', sprintf('%d.%06d', $seconds, $microseconds));
    
    // If there is an error in the creation of the DateTime object the server must know
    if (!$dateTime) {
        throw new Exception('There has been an error trying to convert the float number into Datetime.');
    }
    
    return $dateTime;
}

function getID($deviceName){
    // WE make the connection to the database
    $db=initiateMySQL();

    $device = $db -> prepare("SELECT deviceID FROM devices WHERE deviceID=:deviceName");
    unset($content);
    $content['deviceName'] = $deviceName;

    $p1 = $device -> execute($content);
    $p2 = $device -> fetch();

    if ($p2!=null){
        return $p2;
    }else{
        // The device has not been introduced to the database
        print("The device has not been introduced in the database so we cannot identify it.");
    }

}

?>