#!/bin/bash

# Location of the file that contains the information
# Redirect directly to the file in a background process or use tail -f directly.
if [ -e "/dev/ttyACM0" ]; then
    file="/dev/ttyACM0"
elif [ -e "/dev/ttyACM1" ]; then
    file="/dev/ttyACM1"
else
    echo "Neither ttyACM0 nor ttyACM1 exists. The data is not being sent by the nRF Dongle."
    exit 1
fi

# Ensure data.txt is empty initially
> data.txt

# Background process to redirect output continuously
cat "$file" >> data.txt &

# Function to process the new line
process() {
    line="$1"
    # Send the data obtained to the server through https
    curl -X POST -H "Content-Type: application/json" -d "{\"data\":\"$line\"}" https://10.250.3.17:5053/server.php
}

# Loop that waits for the new lines
stdbuf -oL tail -n0 -f "data.txt" | while IFS= read -r line; do
    process "$line"
done
