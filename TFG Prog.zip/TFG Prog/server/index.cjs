//-----------------------------------------------------------------------------------------------------------------
// Genetation of constants-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------

const WebSocket = require('ws');
const app = express();
const morgan = require ('morgan');
const express = require ('express');
const http = require('http');
const requestData = "";
const requestBodyJSON = "";
const req = "";
let responseData = "";
const options = "";


//-----------------------------------------------------------------------------------------------------------------
// Connection configurations---------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------

// Configuration of the communication between the client and the server
wss = new WebSocket.Server({port: 8080});


// Configuration of the CORS to allow connection from different devices 
wss.on('headers', (headers, request) => {
  headers.push('Access-Controll-Allow-Origin: *');
});

wss.on('connection', (ws) => {

  /*
  // Como ENVIAR INFORMACION AL DEVICE DEL SERVIDOR
  const respuesta2 = {
    'tipo': 0,
    'mensaje': 'Usuario registrado',
    'id_jugador': id_usuario
  };
  ws.send(JSON.stringify(respuesta2));
  */


  ws.on('message', (message) => {

    json = JSON.parse(message);

    // Depending of the type of message we will do a different request to the API
    switch (json.type) {
      case '00' :
        // Add a new device to the API

        requestData = {
          deviceId : json.deviceId,
          deviceName : json.deviceName
        };
        requestBodyJSON = JSON.stringify(requestData);
        options = {
          hostname: 'localhost' ,
          path: '/devices' ,
          port: 3000 ,
          method: 'POST' ,
          headers: {
            'Content-Type': 'application/json' ,
            'Content-Length': requestBodyJSON.length
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end(requestData);
      
        break;

      case '10':
        // Add a new package to the API
        
        requestData = {
          packageId : json.packageId,
          deviceSource : json.deviceSource,
          deviceDestination : json.deviceDestination,
          timestamp : json.timestamp
        };
        requestBodyJSON = JSON.stringify(requestData);
        options = {
          hostname: 'localhost' ,
          path: '/packages' ,
          port: 3000 ,
          method: 'POST' ,
          headers: {
            'Content-Type': 'application/json' ,
            'Content-Length': requestBodyJSON.length
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end(requestData);
       
        break;

      case '20' :
        // Add a new current to the API
       
        requestData = {
          currentId : json.currentId,
          deviceSource : json.deviceSource,
          value : json.value,
          timestamp : json.timestamp,
          measurement : json.measurement
        };
        requestBodyJSON = JSON.stringify(requestData);
        options = {
          hostname: 'localhost' ,
          path: '/currents' ,
          port: 3000 ,
          method: 'POST' ,
          headers: {
            'Content-Type': 'application/json' ,
            'Content-Length': requestBodyJSON.length
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end(requestData);

        break;

      case '02':
        // Delete a device from the API

        options = {
          hostname: 'localhost' ,
          path: '/devices/' + json.deviceId,
          port: 3000 ,
          method: 'DELETE' ,
          headers: {
            'Content-Type': 'application/json' ,
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end();
        break;

      case '12':
        // Delete a package from the API

        options = {
          hostname: 'localhost' ,
          path: '/packages/' + json.packageId,
          port: 3000 ,
          method: 'DELETE' ,
          headers: {
            'Content-Type': 'application/json' ,
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end();

        break;

      case '22':
        // Delete a current from the API

        options = {
          hostname: 'localhost' ,
          path: '/currents/' + json.currentId,
          port: 3000 ,
          method: 'DELETE' ,
          headers: {
            'Content-Type': 'application/json' ,
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end();

        break;
        
      case '01':
        // Obtain information related to a specific device

        options = {
          hostname: 'localhost' ,
          path: '/devices/' + json.deviceId,
          port: 3000 ,
          method: 'GET' ,
          headers: {
            'Content-Type': 'application/json' ,
          }
        }

        req = http.request(options, (res) => {
          responseData = '';
        
          res.on('data', (chunk) => responseData += chunk);
          res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
        });
        req.on('error', (error) => console.error('There has been an error while processing the request:', error));

        // Sending the body of the request
        req.end();
        break;

        case '11':
          // Obtain information related to a specific package
          options = {
            hostname: 'localhost' ,
            path: '/packages/' + json.packageId,
            port: 3000 ,
            method: 'GET' ,
            headers: {
              'Content-Type': 'application/json' ,
            }
          }
  
          req = http.request(options, (res) => {
            responseData = '';
          
            res.on('data', (chunk) => responseData += chunk);
            res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
          });
          req.on('error', (error) => console.error('There has been an error while processing the request:', error));
  
          // Sending the body of the request
          req.end();
          break;

        case '21':
          // Obtain information related to a specific current
          options = {
            hostname: 'localhost' ,
            path: '/currents/' + json.currentId,
            port: 3000 ,
            method: 'GET' ,
            headers: {
              'Content-Type': 'application/json' ,
            }
          }
  
          req = http.request(options, (res) => {
            responseData = '';
          
            res.on('data', (chunk) => responseData += chunk);
            res.on('end', () => console.log('Response from API:', JSON.parse(responseData)));
          });
          req.on('error', (error) => console.error('There has been an error while processing the request:', error));
  
          // Sending the body of the request
          req.end();
          break;
      }
  });

  ws.on('close', () => {
    const id_usuario_desconexion = id_usuario;

  });
});

wss.broadcast = function broadcast(mensaje) {
  wss.clients.forEach(
    function each(cliente) {
      cliente.send(mensaje);
    }
  )
}
