//-----------------------------------------------------------------------------------------------------------------
// Genetation of constants-----------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------

const express = require ('express');
const app = express();
const morgan = require ('morgan');
const fs = require('fs');

const devices = require('./devices.json').devices;
const packages = require('./packages.json').packages;
const currents = require('./currents.json').currents;

//-----------------------------------------------------------------------------------------------------------------
// Connection configurations---------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------

app.set('port', process.env.PORT || 3000);
app.set('json spaces', 2);
app.use(express.json());
app.use((req, res, next)=>{
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods','GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    next();
});

//--------------------------------------------------------------------------------------------------------------
// Functions that will manage the queries
//--------------------------------------------------------------------------------------------------------------

// POST --------------------------------------------------------------------------------------------------------
    function postDevice(req, res){
        const content = req.body;
        const deviceName= content.deviceName;
        const deviceId = content.deviceId;
    
        const cont_device = {"deviceId": deviceId, "deviceName": deviceName};
        devices.push(cont_device);
        
        fs.writeFileSync('/src\\devices.json', JSON.stringify({"devices": devices}));
    
        res.send(cont_device);
    }
  
    function postPackage(req, res){
        const content = req.body;
        const packageId = content.packageId;
        const deviceSource = content.deviceSource;
        const deviceDestination = content.deviceDestination;
        const timestamp = content.timestamp;
    
        const cont_package = {"packageId": packageId, "deviceSource": deviceSource, "deviceDestination": deviceDestination, "timestamp": timestamp };
        packages.push(cont_package);
        
        fs.writeFileSync('/src\\packages.json', JSON.stringify({"packages": packages}));
    
        res.send(cont_package);
    }
  
    function postCurrent(req, res){
        const content = req.body;
        const currentId = content.currentId;
        const deviceSource = content.deviceSource;
        const value = content.value;
        const timestamp = content.timestamp;
        const measurement = content.measurement;
    
        const cont_current = { "currentId": currentId, "deviceSource": deviceSource, "value": value, "timestamp": timestamp, "measurement": measurement};
        currents.push(cont_current);
    
        fs.writeFileSync('/src\\currents.json', JSON.stringify({"currents": currents}));
        res.send(cont_current);
    }
  
// GET --------------------------------------------------------------------------------------------------------
    function getDevice(req,res){
        const deviceId = req.params.deviceId;

        for (i=0; i<devices.length; i++){
            if (devices[i].deviceId == deviceId){
                res.json({
                    "deviceId" : devices[i].deviceId,
                    "deviceName" : devices[i].deviceName,
                });

                break;
            }
        }
    }

    function getPackage(req,res){
        const packageId = req.params.packageId;
        
        for (i=0; i<packages.length; i++){
            if (packages[i].packageId == packageId){
                res.json({
                    "packageId": packages[i].packageId,
                    "deviceSource": packages[i].deviceSource,
                    "deviceDestination": packages[i].deviceDestination,
                    "timestamp": packages[i].timestamp,
                });

                break;
            }
        }
    }

    function getCurrent(req,res){
        const currentId = req.params.currentId;
        
        for (i=0; i<currents.length; i++){
            if (currents[i].currentId == currentId){
                res.json({
                    "currentId": currents[i].currentId,
                    "deviceSource": currents[i].deviceSource,
                    "value": currents[i].value,
                    "timestamp": currents[i].timestamp,
                    "measurement": currents[i].measurement
                });

                break;
            }
        }
    }

// DELETE -----------------------------------------------------------------------------------------------------
    function deleteDevice(req,res){
        const deviceId =req.params.deviceId;
        
        for (i=0; i<devices.length; i++){
            if (devices[i].deviceId==deviceId){
                devices.splice(i,1);
                break;
            }
        }
        fs.writeFileSync('src\\devices.json', JSON.stringify({"devices": devices}));
        res.send(devices);
    }

    function deletePackage(req,res,json){
        const packageId = req.params.packageId;
    
        for (i=0; i<packages.length; i++){
        if (packages[i].packageId==packageId){
            packages.splice(i,1);
            break;
        }
        }
        fs.writeFileSync('src\\packages.json', JSON.stringify({"packages": packages}));
        res.send(packages);
    }

    function deleteCurrent(req,res){
        const currentId = req.params.currentId;
    
        for (i=0; i<currents.length; i++){
        if (currents[i].currentId==currentId){
            currents.splice(i,1);
            break;
        }
        }
        fs.writeFileSync('src\\currents.json', JSON.stringify({"currents": currents}));
        res.send(currents);
    }


// Petitions to the API--------------------------------------------------------------------------------------

  app.post('devices/', postDevice);
  app.post('packages/', postPackage);
  app.post('currents/', postCurrent);

  app.get('/devices/:deviceId', getDevice);
  app.get('/packages/:packageId', getPackage);
  app.get('/currents/:currentId', getCurrent);

  app.delete('/devices/:deviceId', deleteDevice);
  app.delete('/packages/:packageId', deletePackage);
  app.delete('/currents/:currentId', deleteCurrent);
  

//Codificamos el listening para que nuestro servidor funcione y escuche el puerto
app.listen(app.get('port'),()=>{
    console.log(`Server listening on port ${app.get('port')}`);
});
