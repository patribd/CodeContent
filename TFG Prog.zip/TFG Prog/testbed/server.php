<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    
    $rawData = file_get_contents("php://input");
    $jsonData = json_decode($rawData, true);

    if ($jsonData && isset($jsonData['data'])){
        $dataArray = htmlspecialchars($jsonData['data']);
        $data = explode("," , $dataArray);
        echo "The data was received : ". htmlspecialchars($jsonData['data']);
        include("storeData.php");
        //exec(" php /home/raspberrypi/Desktop/testbed/storeData.php ". $data);
        
    }else{
        http_response_code(400);
        echo "Invalid data.";

    }

}else{
    http_response_code(405);
    echo "The system needs a POST request.";
}

?>

