package representers;

public class Job implements Comparable<Job>{
	private static int jobCounter = 0;
    private int jobId;
    private String title;
    private String description;
    private String category;
    private boolean isPaid;
    private float price;
    private boolean isAvailable;


    // Constructor for the paid jobs
    public Job(String title, String description, String category, boolean isPaid, float price) {
        this.jobId = ++jobCounter;
        this.title = title;
        this.description = description;
        this.category = category;
        this.isPaid = isPaid;
        this.price = isPaid ? price : 0;
        this.isAvailable = true;
    }
    
    public int getJobId() {
        return jobId;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void markAsUnavailable() {						// Change availablitiy of the job
        isAvailable = false;
    }
    
    public String getCategory() {	
        return category;
    }

    public boolean isPaid() {
        return isPaid;
    }
    
    @Override
    public int compareTo(Job other) {  						// Compare jobs by their IDs
        return Integer.compare(this.jobId, other.jobId);
    }

    public String toString() {    							// Printing all the information of the jobs in the specified format
        return "Job ID: " + jobId + ", Title: " + title + ", Description: " + description + 
               ", Category: " + category + (isPaid ? ", Price: " + price : "");
    }

}
