package representers;

public class User {
	private static int userCounter = 0;			// Changed from the first submission, now it won�t generate problems when removing a random user
    private int userId;
    private String name;
    private String email;
    private String street;

    // Constructor for the users
    public User(String name, String email, String street) {
        this.userId = ++userCounter;
        this.name = name;
        this.email = email;
        this.street = street;
    }

    // Printing all the information of the users
    public String toString(){
        return userId + ", " + name + ", " + email + ", " + street;
    }
    
    // Get the information of a specific user
    public int getUserID() {
        return userId;
    }
    
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getStreet() {
        return street; 						// Return the user's street address
    }

}