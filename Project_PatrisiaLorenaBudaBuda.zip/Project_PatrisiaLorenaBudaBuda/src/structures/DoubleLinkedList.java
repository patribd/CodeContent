package structures;

public class DoubleLinkedList<T> {
	// Inner class representing an element in the double linked list
    private class DoubleLinkedListElement {
    	
        private T data;															// Data stored in the node
        private DoubleLinkedListElement nextElement;							// Pointer to the next node
        private DoubleLinkedListElement previousElement;						// Pointer to the previous node

     // Constructor for creating a new element with data, next, and previous pointers
        public DoubleLinkedListElement(T v, DoubleLinkedListElement next, DoubleLinkedListElement previous) {
            this.data = v;
            this.nextElement = next;
            this.previousElement = previous;

            if(nextElement != null) nextElement.previousElement = this;			// Link the new element with the next node
            if(previousElement != null) previousElement.nextElement = this;		// Link the new element with the previous node
        }

        public DoubleLinkedListElement(T v) {									// Constructor for creating an isolated node with only data
            this(v,null,null);
        }

        public DoubleLinkedListElement previous() {								// Returns the previous node
            return previousElement;
        }

        public T value() {														// Returns the value (data) of the node
            return data;
        }

        public DoubleLinkedListElement next() {									// Returns the next node
            return nextElement;	
        }

        public void setNext(DoubleLinkedListElement value) {					// Updates the next pointer of the node
            nextElement = value;
        }

        public void setPrevious(DoubleLinkedListElement value) {				// Updates the previous pointer of the node
            previousElement = value;
        }
    }

    private int count;															// Keeps track of the number of elements in the list
    private DoubleLinkedListElement head;										// Pointer to the first node in the list
    private DoubleLinkedListElement tail;										// Pointer to the last node in the list


    public DoubleLinkedList() {													// Constructor to initialize an empty double linked list
        head = null;
        tail = null;
        count = 0;
    }

    public T getFirst() {														// Returns the value of the first node
    	if (head == null) {
            return null; 														// List is empty
        }
    	return head.value();
    }

    public T getLast() {														// Returns the value of the last node
    	if (tail == null) {
            return null;														// List is empty
        }
    	return tail.value();
    }

    public int size() {															// Returns the number of elements in the list
        return count;
    }

    public void addFirst(T newValue) {											// Adds a new element to the beginning of the list
        head = new DoubleLinkedListElement(newValue, head, null);				// Create a new element as the head
        if (tail == null) {														// If the list was empty, set tail to the new head
        	tail = head;
        }
        count++;																// Increment the size of the list
    }

    public void addLast(T newValue) {											// Adds a new element to the end of the list
        tail = new DoubleLinkedListElement(newValue, null, tail);				// Create a new element as the tail
        if (head == null) {														// If the list was empty, set head to the new tail
        	head = tail;
        }
        count++;																// Increment the size of the list
    }

    public String toString() {													// Returns a string representation of the list from head to tail
        String s = "(";
        DoubleLinkedListElement d = head;
        while(d != null) {
            s += d.value().toString();											// Append the value of each node
            s += " ";
            d = d.next();														// Move to the next node
        }
        s += ")";
        return s;

    }

    public String printReverse(){												// Returns a string representation of the list from tail to head
        String s = "(";
        DoubleLinkedListElement d = tail;   									// Start from the last node
        while(d != null){	
            s += d.value().toString();											// Append the value of each node
            s += " ";
            d = d.previous();													// Move to the previous node
        }
        s += ")";
        return s;
    }

    public void removeFirst () {												// Removes the first element in the list
    	if (head == null) {
            return; 															// List is empty
        }
    	head = head.next ();													// Move head to the next node

        if (head == null) {
        	tail = null;														// If the list becomes empty, set tail to null
        }else {
        	head.setPrevious(null);												// Disconnect the new head from the old one
        }
        
        count --;																// Decrease the size of the list
    }


    public void removeLast() {													// Removes the last element in the list
    	if (tail == null) {
            return; 															// List is empty
        }
    	tail = tail.previous();  												// Move tail to the previous node

        if (tail == null) {
            head = null;         												// If tail is null, the list is now empty
        } else {
            tail.setNext(null);  												// Disconnect the new tail from the old tail
        }
        count--;                 												// Decrease the count
    }

    public void reverse() {
        DoubleLinkedListElement currentNode = head;  		 					// Start at the head
        DoubleLinkedListElement temporaryPointer = null;     					// Temporary pointer for swapping

        while (currentNode != null) {
            // Swap next and previous pointers
            temporaryPointer = currentNode.next();           					// Save the next node
            currentNode.setNext(currentNode.previous());     					// Set next to previous
            currentNode.setPrevious(temporaryPointer);       					// Set previous to next (from temporaryPointer)

            currentNode = temporaryPointer;                  					// Move to the next node
        }

        // Swap head and tail
        temporaryPointer = head;
        head = tail;
        tail = temporaryPointer;
    }
}
