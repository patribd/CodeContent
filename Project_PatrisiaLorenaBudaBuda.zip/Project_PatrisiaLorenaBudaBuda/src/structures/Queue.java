package structures;

public class Queue<T extends Comparable<T>> {

	/*
	// Implementation using vectors ---------------------------------------------------------------------------------------

	private Vector<T> data;							// A generic Queue implementation using a Vector
	
	public Queue() {								// Constructor to initialize the vector with a default capacity of 100
		data = new Vector<>(100);
	}

	public void push(T newElement) {				// Method to add a new element to the queue
		data.addLast(newElement);					// Adds the element to the end of the vector
	}

	public T pop() {								// Method to remove and return the front element of the queue
		if (data.isEmpty()){						// Check if the queue is empty
			return null;							// Return null if no elements are present
		}else{
			Object frontElement = data.getFirst();	// Retrieve the front element
			data.removeFirst();						// Remove the front element from the queue
			return frontElement; 					// Return the removed element
		}
	}

	public T top() {								// Method to retrieve the front element of the queue without removing it
		return data.getFirst();						// Return the first element in the vector
	}

	public int size() {								// Method to get the number of elements in the queue
		return data.size();							// Return the size of the vector
	}

	public boolean empty() {						// Method to check if the queue is empty
		return data.isEmpty();						// Return true if the vector has no elements
	}

	public String toString() {						// Method to convert the queue into a string representation
		return "Queue: " + data.toString(); 		// Use the vector's toString method to print the content
	}
	 */

	// Implementation using LinkedLists ---------------------------------------------------------------------------------------

	private LinkedList<T> data;						// The underlying data structure to store queue elements

	public Queue(){									// Constructor to initialize the linked list
		data = new LinkedList<>();					// Create an empty linked list to represent the queue
	}

	public void push(T newElement){					// Method to add a new element to the end (rear) of the queue
		data.addLast(newElement);					// Adds the element to the end of the linked list
	}

	public T pop() {								// Method to remove and return the front element of the queue --> FIFO
		if (data.isEmpty()){						// Check if the queue is empty
			return null;							// Return null if no elements are present
		}else{
			T frontElement = data.getFirst();		// Retrieve the front element
			data.removeFirst();						// Remove the front element from the queue
			return frontElement;					// Return the removed element
		}
	}

	public T top(){									// Method to retrieve the front element of the queue without removing it
		return data.getFirst();						// Returns the first element in the linked list
	}

	public int size(){								// Method to get the number of elements in the queue
		return data.size();							// Return the number of elements in the linked list
	}

	public boolean empty(){							// Method to check if the queue is empty
		return data.isEmpty();						// Return true if the linked list has no elements
	}

	public String toString() {						// Method to convert the queue into a string representation
		return "Queue: " + data.toString(); 		// Use the vector's toString method to print the content
	}

}
