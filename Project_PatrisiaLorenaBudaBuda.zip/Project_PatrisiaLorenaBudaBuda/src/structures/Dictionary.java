package structures;

/*
//IMPLEMENTATION USING VECTORS
public class Dictionary<K extends Comparable<K>, V>  {
 // Inner class representing a key-value pair in the dictionary
 private class DictionaryPair implements Comparable<DictionaryPair> {
     private K key;														// The key, which is used for comparisons
     private V value;													// The value associated with the key

     public DictionaryPair(K key, V value) { 							// Constructor to initialize a key-value pair
         this.key = key;
         this.value = value;
     }

     public K getKey() {												// Getter for the key
         return key;
     }

     public void setKey(K key) { 										// Setter for the key
         this.key = key;
     }

     public V getValue() {												// Getter for the value
         return value;
     }

     public void setValue(V value) {									// Setter for the value
         this.value = value;
     }

     public int compareTo(DictionaryPair o) {							// Method to compare this DictionaryPair with another based on the key
         return key.compareTo(o.key);
     }

     public String toString() {											// Converts the key-value pair to a string for easy debugging or display
         return key + "=" + value;
     }
 }

 private Vector<DictionaryPair> data;									// Stores all the key-value pairs in the dictionary

 public Dictionary() {													// Constructor to initialize the dictionary with a default size
     data = new Vector<>(10);											// Initializes the vector with a capacity of 10
 }

 public void add(K key, V value){										// Adds a key-value pair to the dictionary
     int position = findPosition(key); 									// Find the position of the key in the dictionary

     if (position != -1) {
         // Overwrite the value if it already exists
         DictionaryPair existingPair = data.get(position);
         existingPair.setValue(value);
     } else {
         // Create a new pair and add it to the Dictionary if it does not
         DictionaryPair newPair = new DictionaryPair(key, value);
         data.addLast(newPair); 											// Add the pair to the end of the vector
     }
 }

 public int findPosition(K key) {										// Finds the position of a key in the dictionary
     for (int i = 0; i < data.size(); i++){
         DictionaryPair pair = data.get(i);
         if (pair.getKey().equals(key)){								// Compare the given key with the pair's key
             return i;													// Key found, return its index
         }
     }
     return -1;															// Key not found, return -1
 }

 public V find(K key) {													// Finds the value associated with a given key
     int position = findPosition(key);									// Find the position of the key in the Dictionary
     if (position != -1){
         DictionaryPair pair = data.get(position);
         return pair.getValue();										// Return the value if the key exists
     }
     return null;														// Return null if the key does not exist
 }

 public void removeKey(K key) {
     int position = findPosition(key);									// Find the position of the key in the Dictionary
     if (position != -1){
         for (int i = position; i < data.size() -1; i++){				// Shift all elements after the key to fill the gap
             data.set(i, data.get(i + 1));
         }
         data.removeLast();												// Remove the last element after shifting
     }
 }

 public int size() {
     return data.size();												// Returns the number of key-value pairs in the dictionary
 }

 public String toString() {												// Converts the entire dictionary to a string representation
     StringBuilder stringBuilder = new StringBuilder("{");
     for (int i = 0; i < data.size(); i++) {
         stringBuilder.append(data.get(i));								// Append each key-value pair
         if (i < data.size() - 1) {
             stringBuilder.append(", ");								// Add a comma between pairs
         }
     }
     stringBuilder.append("}");
     return stringBuilder.toString();									// Return the formatted string
 }
}
*/

//A generic Dictionary class implemented using a binary search tree
public class Dictionary<K extends Comparable<K>, V> {

	 private DictionaryTree<K, V> tree;                                      // Binary search tree to store key-value pairs
	 private int size;                                                       // Field to track the size of the dictionary
	
	 public Dictionary() {                                                   // Constructor to initialize the dictionary
	     tree = new DictionaryTree<>();                                      // Initialize the tree
	     size = 0;                                                           // Initialize size to 0
	 }
	
	 public void add(K key, V newValue) {                                    // Add a key-value pair to the dictionary
	     V existingValue = find(key);                                        // Check if the key already exists in the dictionary
	     if (existingValue == null) {
	         size++;                                                         // Increment size if the key is new
	     }
	     tree.add(key, newValue);                                            // Add the key-value pair to the tree
	 }
	
	 public V find(K key) {                                                  // Find the value associated with a key
	     return tree.getValueForKey(key);                                    // Use the tree's method to get the value for the specific key
	 }
	
	 public V findKey(K key) {                                               // Alias for the find method to find the value associated with a key
	     return find(key);                                                   // Delegate to the find method for consistency
	 }
	
	 public void removeKey(K key) {                                          // Remove a key-value pair from the dictionary
	     V existingValue = find(key);                                        // Check if the key exists before removing
	     if (existingValue != null) {
	         size--;                                                         // Decrement size if the key exists
	     }
	     tree.remove(key);                                                   // Remove the key-value pair from the tree
	 }
	
	 public int size() {                                                     // Return the size of the dictionary (number of key-value pairs)
	     return size;                                                        // Return the size field
	 }
	
	 @Override
	 public String toString() {                                              // Convert the dictionary to a string representation
	     return tree.toString();                                             // Delegate the toString implementation to the tree
	 }

}




