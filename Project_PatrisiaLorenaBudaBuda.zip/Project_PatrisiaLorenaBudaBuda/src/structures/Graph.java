package structures;

public class Graph<T extends Comparable<T>> {

    public class Node implements Comparable<Node> {
        private T info;															// The label or value of the node
        private LinkedList<Edge> edges; 										// List of edges connected to this node

        public Node(T label) {
            info = label;														// Initialize node label
            edges = new LinkedList<>(); 										// Initialize edges list
        }

        public void addEdge(Edge e) {
            if (e == null) {
                throw new IllegalArgumentException("Cannot add a null edge.");	// Ensure the edge is not null
            }
            edges.addLast(e);													// Add the edge to the list of edges
           
        }

        @Override
        public int compareTo(Node o) {
            return this.info.compareTo(o.info);									// Compare nodes based on their labels
        }

        public T getLabel() {
            return info;														// Get the label of this node
        }

        public LinkedList<Edge> getEdges() {
            return edges;														// Get the list of edges for this node
        }
    }

    private class Edge implements Comparable<Edge> {							// Class to represent an edge in the graph
        private Node toNode;													// Destination node of the edge
        private double weight;													// Weight of the edge

        public Edge(Node to, double weight) {									// Constructor to initialize an edge with a destination node and weight
            toNode = to;														// Set the destination node
            this.weight = weight;												// Set the edge weight
        }

        public Node getToNode() {
            return toNode;														// Get the destination node
        }

        public double getWeight() {
            return weight;														// Get the weight of the edge
        }

        @Override
        public int compareTo(Edge other) {
            return Double.compare(this.weight, other.weight);					// Compare edges based on their weight
        }
    }

    private LinkedList<Node> nodes; 											// List of nodes in the graph

    public Graph() {
        nodes = new LinkedList<>(); 											// Initialize the empty graph
    }

    public void addNode(T label) {
        if (findNode(label) != null) {											// Check if the node already exists
            return; 															// Do nothing if the node already exists
        }

        nodes.addLast(new Node(label));  										// Add the new node
       
    }

    private Node findNode(T nodeLabel) {
        for (int i = 0; i < nodes.size(); i++) {								// Iterate through all nodes
            Node currentNode = nodes.get(i);
            if (currentNode != null && currentNode.getLabel().equals(nodeLabel)) {
                return currentNode;												// Return the node if it matches the label
            }
        }
        return null;															// Return null if the node is not found
    }

    private Node binarySearch(LinkedList<Node> list, T key, int low, int high) {// Perform binary search on a sorted LinkedList of nodes
        if (low > high) {
            return null; 														// Node not found
        }

        int mid = low + (high - low) / 2;
        Node middleNode = list.get(mid);

        int compare = key.compareTo(middleNode.getLabel());
        if (compare == 0) {
            return middleNode; 													// Node found
        } else if (compare < 0) {
            return binarySearch(list, key, low, mid - 1); 						// Search in the left half
        } else {
            return binarySearch(list, key, mid + 1, high); 						// Search in the right half
        }
    }

    public void addEdge(T nodeLabel1, T nodeLabel2, double weight) {			// Add an edge between two nodes
        // Ensure both nodes exist in the graph
        if (findNode(nodeLabel1) == null) {
            addNode(nodeLabel1);
           
        }
        if (findNode(nodeLabel2) == null) {
            addNode(nodeLabel2);
           
        }
        // Retrieve the nodes
        Node n1 = findNode(nodeLabel1);
        Node n2 = findNode(nodeLabel2);

        // Check if the nodes were successfully retrieved
        if (n1 == null || n2 == null) {
            throw new IllegalStateException("Failed to retrieve nodes for edge creation. Try again.");
        }

        // Create and add the edge
        Edge edge = new Edge(n2, weight);
        n1.addEdge(edge);

    }

   
    private LinkedList<T> convertPathToLabels(LinkedList<Node> path) {			// Convert a path of nodes to a path of labels
        LinkedList<T> labels = new LinkedList<>();
        for (int i = 0; i < path.size(); i++) {
            labels.addLast(path.get(i).getLabel());
        }
        return labels;
    }

    public void addTree(Tree tree) {											// Add a binary tree to the graph
        addTreeRecursive(tree.root); 											// Recursively add nodes and edges
    }

    private void addTreeRecursive(Tree.TreeNode currentNode) {					// Recursively add nodes and edges from a tree
        if (currentNode == null) {
            return;
        }

        // Add the current node to the graph if not already present
        if (findNode((T) currentNode.getValue()) == null) {
            addNode((T) currentNode.getValue());
        }

        // Add edges to the left and right children --> if they exist
        if (currentNode.getLeftTree() != null) {
            if (findNode((T) currentNode.getLeftTree().getValue()) == null) {
                addNode((T) currentNode.getLeftTree().getValue());
            }
            addEdge((T) currentNode.getValue(), (T) currentNode.getLeftTree().getValue(), 1.0);
        }

        if (currentNode.getRightTree() != null) {
            if (findNode((T) currentNode.getRightTree().getValue()) == null) {
                addNode((T) currentNode.getRightTree().getValue());
            }
            addEdge((T) currentNode.getValue(), (T) currentNode.getRightTree().getValue(), 1.0);
        }

        // Recursively handle the left and right subtrees
        addTreeRecursive(currentNode.getLeftTree());
        addTreeRecursive(currentNode.getRightTree());
    }



    @Override
    public String toString() { 													// Convert the graph to an adjacency list representation
        StringBuilder s = new StringBuilder();
        s.append("Adjacency List Representation:\n");

        // Use a simple index-based loop to iterate through nodes
        for (int i = 0; i < nodes.size(); i++) {
            Node node = nodes.get(i); 											// Access node at index i
            if (node == null) continue;
            s.append(node.getLabel()).append(": ");

            LinkedList<Edge> edges = node.getEdges();
            if (edges != null) {
                // Use another index-based loop for edges
                for (int j = 0; j < edges.size(); j++) {
                    Edge edge = edges.get(j);
                    if (edge != null) {
                        s.append("(").append(edge.getToNode().getLabel()).append(", weight=").append(edge.getWeight()).append(") ");
                    }
                }
            }

            if (s.charAt(s.length() - 1) == ' ') {
                s.setLength(s.length() - 1);           							// Trim trailing space
            }
            s.append("\n");
        }

        return s.toString();
    }
    
    public LinkedList<T> bfsShortestPath(T start, T end) {						// Finding the shortest path from one node to another
        Node startNode = findNode(start);
        Node endNode = findNode(end);

        if (startNode == null || endNode == null) {
            throw new IllegalArgumentException("One or both of the nodes do not exist in the graph.");
        }

        // Data structures used for BFS
        LinkedList<Node> queue = new LinkedList<>();
        DictionaryTree<T, T> previous = new DictionaryTree<>(); 				// Track the path
        LinkedList<Node> visited = new LinkedList<>();

        // Enqueue the starting node and mark it as visited
        queue.addLast(startNode);
        visited.addLast(startNode);
        previous.add(startNode.getLabel(), null); 								// No previous node for the start node

        while (!queue.isEmpty()) {
            Node current = queue.get(0); 										// Get the first node in the queue
            queue.removeFirst(); 												// Remove it from the queue

            // Check if we have reached the destination node
            if (current == endNode) {
            	// The destination node is reached
                break;
            }

            // Traverse all edges of the current node
            LinkedList<Edge> edges = current.getEdges();
            for (int i = 0; i < edges.size(); i++) {
                Edge edge = edges.get(i);
                if (edge == null) {
                    
                    continue;
                }

                Node neighbour = edge.getToNode();
               
                // If the neighbor has not been visited --> enqueue it
                if (!visited.contains(neighbour)) {
                    queue.addLast(neighbour);
                    visited.addLast(neighbour);
                    previous.add(neighbour.getLabel(), current.getLabel());
                    
                }
            }
        }

        // Reconstruct the path from end to start 
        LinkedList<T> path = new LinkedList<>();
        T step = end;
        while (step != null) {
            path.addFirst(step);
            step = previous.getValueForKey(step);
        }

        // If the reconstructed path does not start with the start node --> it's invalid
        if (path.isEmpty() || !path.getFirst().equals(start)) {
            System.out.println("No valid path found from " + start + " to " + end);
            return null;
        }

        return path;
    }
 
}