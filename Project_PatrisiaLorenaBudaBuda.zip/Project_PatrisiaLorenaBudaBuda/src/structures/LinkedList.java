package structures;

public class LinkedList<T extends Comparable<T>> implements Comparable<LinkedList<T>>{

    // Inner class representing an element in the linked list
    private class ListElement {

        private T value;										// The data stored in this node
        private ListElement next;								// Pointer to the next node in the list

        // Constructor to create a node with a value and a link to the next node
        public ListElement(T value, ListElement next) {
            this.value = value;
            this.next = next;
        }

        // Constructor to create a node with a value, next defaults to null
        public ListElement(T el) {
            this(el, null);
        }

        public T first() {
            return value;										// Get the value of this node
        }

        public ListElement rest() {								// Get the next node
            return next;
        }

        public void setFirst(T value) {							// Set the value of this node
            this.value = value;
        }

        public void setRest(ListElement next) { 				// Set the next node
            this.next = next;
        }
    }

    private ListElement head;									// The head of the linked list
    private int count;											// Number of elements in the linked list

    public LinkedList() { 										// Constructor for an empty linked list
        head = null;
        count = 0;
    }

    public void addSorted(T data) {
        ListElement newElement = new ListElement(data);

        // Case 1 (theory): Empty list, add the new element as the head
        if (head == null) {
            head = newElement;									// New element becomes the head
            count++;
            return;
        }

        // Case 2 (theory):: New element should be inserted at the front
        if (head.first().compareTo(data) > 0) {
            newElement.setRest(head);							// The new element points to the previous head
            head = newElement;									// New element converts to be the head
            count++;
            return;
        }

        // Case 3 (theory):: Traverse the list to find the correct position
        ListElement current = head;
        while (current.rest() != null && current.rest().first().compareTo(data) < 0) {
            current = current.rest();
        }

        // Insert the new element at the correct position
        newElement.setRest(current.rest());
        current.setRest(newElement);
        count++;
    }

    public T getFirst() {                                       // Get the first element of the list
        if (head == null) {
            return null;										// List is empty
        }else {
            return head.first();								// Return the value of the head box
        }
    }

    public T getLast(){											// Get the last element of the list
        if (head == null) {
            return null;										// List is empty
        }
        ListElement d = head;
        while (d.rest() != null) {
            d = d.rest();										// Traverse to the end of the list
        }
        return d.first();
    }

    public void addFirst(T newValue) {							// Add a new element at the start of the list
        head = new ListElement(newValue, head);					// New element becomes the head
        count++;
    }

    public void addLast(T newValue) {							// Add a new element at the end of the list
        if (head == null) {
            // The list is empty, the element will be directly the head
            addFirst(newValue);
        }else{
            // Traverse to the end and add the new element
            ListElement d = head;
            while (d.rest() != null) {
                d = d.rest();
            }
            d.setRest(new ListElement(newValue));
        }
        count++;
    }

    public T get(int index) {									// Get the element at a specific index
        if (index < 0 || index >= count) {
            return null; 										// Index out of bounds
        }
        ListElement d = head;
        for (int i = 0; i < index; i++) {
            d = d.rest();										// Traverse to the specified index
        }
        return d != null ? d.first() : null;
    }

    public int size() {											// Get the size of the list
        return count;
    }

    public boolean contains(T value) {							// Check if the list contains a specific value
        ListElement d = head;
        while (d.rest() != null) {
            if (d.first().equals(value)) {						// Comparing values using equals() so we can check any type of values
                return true;
            }
            d = d.rest();
        }
        return false;
    }

    public void removeFirst(){									// Remove the first element of the list
        if (head == null) {
            return;												// There is no head in the LinkedList --> the list is empty --> nothing to remove
        }
        head = head.rest(); 									// Just move the head to point the next element of the list
        count--;
    }

    public void removeLast() {									// Remove the last element of the list
        if (head == null) {										// There is no head in the LinkedList --> the list is empty --> nothing to remove
            return;
        }
        if (head.rest() == null) {								// If there's only one element (which is also the head), set head to null
            head = null;
            count--;
            return;
        }
        ListElement d = head;
        while (d.rest().rest() != null) {
            d = d.rest(); 										// Traverse until the previous of the last element of the list
        }
        d.setRest(null); 										// Set last element to null
        count--;
    }

    public void set(int index, T newValue) { 					// Update the value of an element at a specific index
        if (index < 0 || index >= count) {
            return; 											// Index out of bounds
        }
        ListElement d = head;
        for (int i = 0; i < index; i++) {
            d = d.rest();										// Traverse to the specified index
        }
        d.setFirst(newValue);
    }

    public boolean isEmpty(){ 									// Check if the list is empty
        return head == null; 									// There is no head in the LinkedList --> the list is empty

    }

    public void reverse() { 									// Reverse the linked list
        if (head == null || head.rest() == null) {
            return;												// The list is empty or has only one element --> it's already reversed
        }

        ListElement previousNode = null;
        ListElement currentNode = head;
        ListElement nextNode;

        while (currentNode != null) {
            nextNode = currentNode.rest();  					// Store the next node
            currentNode.setRest(previousNode); 					// Reverse the pointer
            previousNode = currentNode;     					// Move 'previous' to the current node
            currentNode = nextNode;          					// Move 'current' to the next node
        }

        head = previousNode; 									// Update the head to the new first element
    }

    public void fropple() {										// Swap adjacent elements in pairs
        if (head == null || head.rest() == null) {
            return; 											// Empty list or only one element
        }

        ListElement previousNode = null; 						// Tracks the last node of the previous pair --> I was not changing the previous pointer once swapped the next pair
        ListElement currentNode = head; 						// Start at the head of the list

        head = currentNode.rest();								// Update the head to point to the second element after the first swap

        while (currentNode != null && currentNode.rest() != null) {			// We are not at the end of the list
            ListElement first = currentNode;
            ListElement second = currentNode.rest();

            // Swap the pair
            first.setRest(second.rest()); 						// First's rest now points to the node after the second
            second.setRest(first);        						// Second's rest now points to the first

            // Connect the previous pair to the current pair's new head
            if (previousNode != null) {
                previousNode.setRest(second);
            }

            previousNode = first;								// Move the 'previousNode' pointer variable to the last node of the current pair

            currentNode = first.rest();							// Move 'currentNode' variable to the first node of the next pair
        }
    }

    public void append(LinkedList list2) {						// Append another linked list to this one
        ListElement currentNode = list2.head;					// Start at the head of the second list

        // Traverse the second list
        while (currentNode != null) {
            this.addLast(currentNode.first());					// Add each element of list2 to the end of the current list (this)
            currentNode = currentNode.rest();
        }
    }

    public String toString() {									// Convert the linked list to a string representation
        String s = "(";
        ListElement d = head;
        while (d != null) {
            s += d.first().toString();							// Convert each element into a string to print
            s += " ";
            d = d.rest();
        }
        s += ")";
        return s;
    }

    // FOR THE GRAPH IMPLEMENTATION
    public void add(int index, T newValue) {
        if (index < 0 || index > count) {
            return;												// Wrong index, cannot be introduced
        }

        if (index == 0) {
            addFirst(newValue);									// Add at first position
            return;
        }

        ListElement current = head;
        for (int i = 0; i < index - 1; i++) {					// Check in which position do we add it --> USED FOR PRIORITY QUEUE
            current = current.rest();
        }

        current.setRest(new ListElement(newValue, current.rest()));
        count++;
    }

    public T find(T key) {                                      // Find an element by its key
        ListElement current = head;
        while (current != null) {                               // The list is not empty
            if (current.first().equals(key)) {                  // Iterate through all the elements
                return current.first();
            }
            current = current.rest();
        }
        return null;                                            // Element not found
    }

    @Override
    public int compareTo(LinkedList<T> other) {                 // Compare two linked lists
        // Compare by size
        if (this.size() < other.size()) {
            return -1;
        } else if (this.size() > other.size()) {
            return 1;
        }

        // Compare element by element if sizes are the same
        ListElement current1 = this.head;
        ListElement current2 = other.head;
        while (current1 != null && current2 != null) {
            int comparison = current1.first().compareTo(current2.first());
            if (comparison != 0) {
                return comparison;
            }
            current1 = current1.rest();
            current2 = current2.rest();
        }

        return 0;                                               // Lists are equal
    }

}
