package structures;


public class Tree {
	/*
	private class NaturalComparator implements Comparator
	{
		public int compare(Object a, Object b)
		{
			return ((Comparable)a).compareTo(b);
		}
	}
	*/
	// The class for implementing a node in the tree.
	// contains a value, a pointer to the left child and a pointer to the right child
	
	public class TreeNode implements Comparable<TreeNode> {
	 private Comparable value;															// Value to compare
	 private TreeNode leftNode;															// The left node (smaller)
	 private TreeNode rightNode;														// The right node (bigger)
	 public TreeNode(Comparable v)														// Constructor for node without children
	 {
	  value = v;
	  leftNode = null;
	  rightNode = null;
	 }
	  
	 public TreeNode(Comparable v, TreeNode left, TreeNode right)						// Constructor for node with children
	 {
	  value = v;
	  leftNode = left;
	  rightNode = right;
	 }
	 public TreeNode getLeftTree()
	 {
	  return leftNode;																	// Returns content from the left side (smaller)
	 }		
	 
	 public TreeNode getRightTree()
	 {
	  return rightNode;																	// Returns content from the right side (bigger)
	 }	
	 
	 
	 public Comparable getValue()
	 {
		 return value;																	// Returns the value
	 }			

	@Override
	public int compareTo(TreeNode o) {
		return this.value.compareTo(o.value);
	}
	}
	
	public static abstract class TreeAction												// Class that allows us to perform generic operations on the tree nodes
	{
		public abstract void run(TreeNode n);
	}
		
	// Start of the actual tree class ------------------------------------------------------------------------------------------------------------------------------------------------
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	protected TreeNode root;															// The root of our tree
	
	public Tree()
	{
		root = null;																	// The value will be null until we change it
	}
	

	/*
	public void traverse(TreeAction action)
	{
//		QueueVector t = new QueueVector();
//		//Stack t = new Stack();
//		t.push(root);
//		while(!t.empty())
//		{
//			TreeNode n = (TreeNode)t.pop();
//			action.run(n);
//			 
//			if(n.getLeftTree() != null) t.push(n.getLeftTree());
//			if(n.getRightTree() != null) t.push(n.getRightTree());
//		}
	}
	 */
	
	public void traverseNode(TreeNode n,TreeAction action)								// Traverse the tree in in-order fashion starting on the current node "n" -->  left subtree - current node - right subtree FOR THR GRAPH
	{
		if(n != null)																	// If it is not null --> it is not the end of that branch
		{
			if(n.getLeftTree() != null) traverseNode(n.getLeftTree(),action); 			// Get the next node of the left subtree
			action.run(n);																// Run the action on the current node
			if(n.getRightTree() != null) traverseNode(n.getRightTree(),action);			// Get the next node of the right subtree
		}
	}
	
	public void traverseInOrder(TreeAction action)										// Traverse the tree with the in-order fashion but starting on the root (whole tree)
	{
		traverseNode(root,action);
	}
	
	public void insert(Comparable element)
	{
		insertAtNode(element,root,null);
	}	
	
	// We traverse the tree.
	// Current holds the pointer to the TreeNode we are currently checking
	// Parent holds the pointer to the parent of the current TreeNode
	private void insertAtNode(Comparable element,TreeNode current,TreeNode parent)
	{
		// If the node we check is empty
		if(current == null)
		{
			TreeNode newNode = new TreeNode(element);
			// The current node is empty, but we have a parent
			if(parent != null)
			{
				if(element.compareTo(parent.value) < 0){
					parent.leftNode = newNode;											// Element < Parent --> LEFT TREE
				}else {
					parent.rightNode = newNode;											// Element > Parent --> RIGHT TREE
				}
			} else root = newNode; 														// The current node is empty and it has no parent, we actually have an empty tree
		} else if (element.compareTo(current.value) == 0) {
			// if the element is already in the tree, we do not do anything
		} else if(element.compareTo(current.value) < 0) { 								// If the element is smaller than current, go left subtree
			insertAtNode(element,current.getLeftTree(),current);
		} else insertAtNode(element,current.getRightTree(),current); 					// If the element is bigger than current, go right subtree
	}

	/*
	// EXERCISE 10.2.1
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	public String toString()
	{
		String s = "";
		Stack t = new Stack();
		t.push(root);
		while (!t.empty())
		{
			TreeNode n = (TreeNode)t.pop();
			s += n.value.toString();
			if(n.getRightTree() != null)
				t.push(n.getRightTree());
			if(n.getLeftTree() != null)
				t.push(n.getLeftTree());
			s += "\n";
		}
		return s;
	}
	 */

	/*
	// EXERCISE 10.2.3
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	public String toString()
	{
		String s = "";
		Queue t = new Queue();
		t.push(root);
		while (!t.empty())
		{
			TreeNode n = (TreeNode)t.pop();
			s += n.value.toString();
			if(n.getRightTree() != null)
				t.push(n.getRightTree());
			if(n.getLeftTree() != null)
				t.push(n.getLeftTree());
			s += "\n";
		}
		return s;
	}
	 */

	// EXERCISE 10.2.4
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	public class TreePrinter extends TreeAction {
		@Override
		public void run(TreeNode n) {
			System.out.println(n.getValue());
		}
	}

	public void traverse(TreeAction action)
	{
		Queue t = new Queue();
		//Stack t = new Stack();
		t.push(root);
		while(!t.empty())
		{
			TreeNode n = (TreeNode)t.pop();
			action.run(n);

			if(n.getLeftTree() != null) t.push(n.getLeftTree());
			if(n.getRightTree() != null) t.push(n.getRightTree());
		}
	}

	// EXERCISE 10.2.5
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	public String toString() {
		if (root == null){
			return "";																	// If the tree is empty return an empty string --> no need to study the tree
		}
		String[] s = {""}; 																// Use a single-element array to hold the mutable string
		traverse(new TreeAction() { 													// Anonymous class to define the action
			@Override
			public void run(TreeNode n) {
				s[0] = s[0] + n.getValue() + " "; 										// Concatenate the value and a space to the string
			}
		});
		return s[0].trim(); 															// Remove trailing space and return the string
	}

	// EXERCISE 10.2.6
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	public int calculateDepth() {														// Method to calculate the depth of the tree
		return calculateDepth(root); 													// Start with the root node
	}

	private int calculateDepth(TreeNode node) {											// Helper method to calculate depth recursively
		if (node == null) {
			return 0; 																	// Empty subtree has depth 0
		}

		int leftDepth = calculateDepth(node.getLeftTree());
		int rightDepth = calculateDepth(node.getRightTree());

		return Math.max(leftDepth, rightDepth) + 1;										// Return the greater of the two depths plus 1 (for the current node)
	}

	// EXERCISE 10.2.7
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	public Comparable findBiggest() {
		if (root != null) {
			return findBiggest(root).getValue(); 										// Call the helper method starting from the root
		}
		return null;
	}

	// Helper method to find the rightmost node iteratively
	private TreeNode findBiggest(TreeNode node) {
		TreeNode current = node;
		while (current.getRightTree() != null) { 										// Traverse to the rightmost node
			current = current.getRightTree();
		}
		return current; 																// The rightmost node is the biggest
	}

	// ADITIONAL FIND THE SMALLEST

	public Comparable findSmallest(){
		if (root != null){
			return findSmallest(root).getValue();
		}
		return null;
	}

	private TreeNode findSmallest(TreeNode node){
		TreeNode current = node;
		while (current.getLeftTree() != null){
			current = current.getLeftTree();
		}
		return current;
	}

	// EXERCISE 10.2.9
	// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	// Swap the left and right subtrees of the entire tree
	public void swapTree() {
		swapSubtrees(root); 															// Start swapping from the root
	}

	// Helper method to swap left and right subtrees of a given node recursively
	private void swapSubtrees(TreeNode node) {
		if (node == null) {
			return; 																	// Base case: If the node is null, do nothing
		}

		// Swap the left and right children of the current node
		TreeNode temp = node.leftNode;
		node.leftNode = node.rightNode;
		node.rightNode = temp;

		// Recursively swap the subtrees of the left and right children
		swapSubtrees(node.leftNode);
		swapSubtrees(node.rightNode);
	}

	// Method to delete a node used in the Priority Queue implementation
	// Method to delete an element from the tree
	public void delete(Comparable element) {
		root = deleteAtNode(element, root); 											// Call the recursive helper method starting from the root
	}

	// Recursive helper method to delete a node
	private TreeNode deleteAtNode(Comparable element, TreeNode current) {
		if (current == null) {
			return null; 																// Element not found in the tree
		}

		if (element.compareTo(current.value) < 0) {
			// If the element is smaller --> go to the left subtree
			current.leftNode = deleteAtNode(element, current.leftNode);
		} else if (element.compareTo(current.value) > 0) {
			// If the element is larger --> go to the right subtree
			current.rightNode = deleteAtNode(element, current.rightNode);
		} else {
			// Element matches the current node --> this is the node to delete

			// Case 1 (theory): Node with no children (leaf node)
			if (current.leftNode == null && current.rightNode == null) {
				return null; 															// Simply remove the node
			}

			// Case 2 (theory): Node with one child
			if (current.leftNode == null) {
				return current.rightNode; 												// Replace the node with its right child
			}
			if (current.rightNode == null) {
				return current.leftNode; 												// Replace the node with its left child
			}

			// Case 3 (theory): Node with two children
			// Find the smallest node in the right subtree (in-order form successor)
			TreeNode smallest = findSmallest(current.rightNode);
			current.value = smallest.value; 											// Replace the value of the current node with the successor's value
			current.rightNode = deleteAtNode(smallest.value, current.rightNode); 		// Delete the successor node
		}

		return current; 																// Return the updated node
	}
}