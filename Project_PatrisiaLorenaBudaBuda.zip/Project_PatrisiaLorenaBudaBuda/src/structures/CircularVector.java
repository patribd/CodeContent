package structures;

public class CircularVector<T extends Comparable<T>> {
    private Vector<T> data;									// Underlying Vector to store elements
    private int first;										// Index of the first element in the circular vector
    private int count;										// Current number of elements in the circular vector
    private int capacity;									// Maximum capacity of the circular vector

    public CircularVector(int capacity) {					// Constructor to initialize the CircularVector with a specified capacity
        this.count = 0;										// Start with an empty CircularVector
        this.first = 0;										// Initialize the first index to 0
        this.data = new Vector<>(capacity);					// Create the underlying Vector with the given capacity
        this.capacity = capacity;							// Set the maximum capacity
        for (int i = 0; i < capacity; i++) {
            this.data.addLast(null);  						// Fill the Vector with `null` values
        }
    }

    public int size() {										// Returns the number of elements currently in the CircularVector
        return count;
    }

    public boolean isEmpty() {
        return count == 0; 									// Checks if the circular vector is empty
    }

    public void addFirst(T newElement) {					// Adds a new element to the beginning of the CircularVector
        if (count == capacity) {
            return; 										// Do nothing if the CircularVector is full
        }
        first = (first + data.size() - 1) % capacity; 		// Move 'first' backwards in circular manner
        data.set(first, newElement);
        count++;
    }

    public void addLast(T newElement) {						// Adds a new element to the end of the CircularVector
        if (count == capacity) {
            return;											// Do nothing if the CircularVector is full
        }
        int lastIndex = (first + count) % capacity; 		// Calculate the position for the new last element
        data.set(lastIndex, newElement);
        count++;
    }

    public T getFirst() { 									// Retrieves the first element in the CircularVector
        if (count == 0) {
            return null;									// Return null if the CircularVector is empty
        }
        return data.get(first);								// Return the element at the `first` index
    }

    public T getLast() {									// Retrieves the last element in the CircularVector
        if (count == 0) {
            return null;									// Return null if the CircularVector is empty
        }
        int lastIndex = (first + count - 1) % capacity; 	// Find the last element index
        return data.get(lastIndex);							// Return the element at the last index
    }

    public void removeFirst() 								// Removes the first element from the CircularVector
    {
        if(!isEmpty())
        {
            first = (first+1) % capacity; 					// Move `first` forward in a circular manner
            count--;
        }
    }

    public void removeLast() { 								// Removes the last element from the CircularVector
        if (!isEmpty()) {
            count--; 										// Reduce the count to "remove" the last element
        }
    }

    public String toString() { 								// Converts the CircularVector to a string representation
        StringBuilder s = new StringBuilder("[");
        for (int i = 0; i < count; i++) {
            // Calculate the circular index for the current element
            int index = (first + i) % capacity;
            s.append(data.get(index)); 						// Add the element to the string
            if (i < count - 1) {
                s.append(", "); 							// Add a comma separator for elements
            }
        }
        s.append("]");										// End the string with a closing bracket
        return s.toString(); 								// Return the final string representation
    }
}
