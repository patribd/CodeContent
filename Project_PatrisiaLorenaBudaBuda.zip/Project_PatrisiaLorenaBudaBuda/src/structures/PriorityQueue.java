package structures;

public class PriorityQueue<E, P extends Comparable<P>> {
    // Inner class representing a pair of element and priority
    private class PriorityPair implements Comparable<PriorityPair> {
        private E element;												// The actual element stored in the queue
        private P priority;												// The priority of the element

        // Constructor to initialize the element and its priority
        public PriorityPair(E element, P priority) {
            this.element = element;
            this.priority = priority;
        }

        public int compareTo(PriorityPair o) {							// Method to compare two PriorityPair objects based on their priority
            return o.priority.compareTo(this.priority);					// Lower priority value indicates higher priority
        }

        public E getElement(){											// Getter for the element
            return element;
        }

        public P getPriority(){											// Getter for the priority
            return priority;
        }

        public String toString() {										// String representation of the PriorityPair (for debugging and display)
            return "(" + element + ", " + priority + ")";
        }

    }

    /*
    // IMPLEMENTATION BASED ON LINKED LIST
    private LinkedList<PriorityPair> data;								// Linked list to store the priority queue elements

    public PriorityQueue() {											// Constructor to initialize an empty priority queue
        data = new LinkedList<>();
    }

    public void push(E o, P priority) {									// Method to add a new element with a given priority to the queue
        PriorityPair newPair = new PriorityPair(o, priority);			// Create a new PriorityPair

        // If the queue is empty --> add the new element as the first
        if (data.isEmpty()) {
            data.addFirst(newPair);
            return;
        }

        // Traverse the linked list to find the correct position for the insertion
        int index = 0;
        while (index < data.size()) {
            PriorityPair currentPair = data.get(index);					// Get the current element in the list
            if (newPair.compareTo(currentPair) < 0) {  					// New element has higher priority
                break;													// Stop when the correct position is found
            }
            index++;
        }

        // Insert the new pair at the determined position
        if (index == data.size()) {
            data.addLast(newPair); 										// If it has the lowest priority, add to the end
        } else {
            data.add(index, newPair);									// Insert at the calculated position
        }
    }


    public E pop(){														// Method to remove and return the element with the highest priority
        if (data.isEmpty()) {
            return null;												// If the queue is empty, return null
        }else{
            E highestPriorityElement = data.getFirst().getElement();	// Get the element at the front
            data.removeFirst();											// Remove the front element from the queue
            return highestPriorityElement;
        }
    }

    public E top(){														// Method to return the element with the highest priority without removing it
        if (data.isEmpty()) {
            return null;												// If the queue is empty, return null
        }else{
            return data.getFirst().getElement();						// Return the element at the front
        }
    }

    public String toString() {
        return "PriorityQueue: " + data.toString();						// String representation of the priority queue (uses the toString method of LinkedList and PriorityPair)
    }
     */

    // IMPLEMENTATION USING THE TREE DATA STRUCTURE RECOMMENDED IN THE MANUAL
    private Tree tree;

    public PriorityQueue(){                                             // Constructor to initialize the priority queue with a tree
        tree = new Tree();                                              // Constructing an empty tree
    }

    public void push(E element, P priority){                            // Method to add a new element
        PriorityPair newPair = new PriorityPair(element, priority);     // Create a new PriorityPair
        tree.insert(newPair);                                           // Insert the PriorityPair into the tree
    }

    public E pop(){                                                     // Method to erase the element with highest priority
        if (tree.root == null){
            return null;                                                // The tree is empty
        }
        Comparable biggest = tree.findBiggest();
        tree.delete(biggest);                                           // Erasing the element
        return ((PriorityPair) biggest).getElement();                   // The pop method returns the element
    }

    public E top() {                                                    // Top method to return the element with the highest priority without removing it
        if (tree.root == null) {
            return null;                                                // The tree is empty                                              
        }
        Comparable biggest = tree.findBiggest();                        // Find the PriorityPair with the highest priority
        return ((PriorityPair) biggest).getElement();                   // Return the element of the PriorityPair
    }

    public String toString() {
        return "PriorityQueue: " + tree.toString();                     // Use the tree's toString method for representation
    }
}