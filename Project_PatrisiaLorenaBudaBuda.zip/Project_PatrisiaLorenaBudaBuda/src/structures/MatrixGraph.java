package structures;

public class MatrixGraph 
{
	private Matrix data;												// The underlying matrix that represents the graph's adjacency matrix
	
	public MatrixGraph(int numberNodes)									// Constructor to create a graph with a specified number of nodes
	{
		data = new Matrix(numberNodes);									// Initialize the matrix with the given number of nodes
	}
	
	public void addEdge(int from, int to, double w)						// Method to add a directed edge from one node to another with a specified weight
	{
		data.set(from, to, w);											// Set the weight in the adjacency matrix
	}
	
	public double getEdge(int from, int to)								// Method to retrieve the weight of the edge between two nodes
	{
		return (Double)data.get(from, to);								// Get the weight from the adjacency matrix
	}

	@Override
	public String toString() {											// Printing all the nodes and edges in the form of an adjancency matrix
		StringBuilder s = new StringBuilder();
		s.append("Adjacency Matrix Representation:\n");					// Title for the adjacency matrix
		Comparable[][] matrix = data.getMatrix(); 						// Retrieve the matrix using the getter method
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				s.append(matrix[i][j]).append(" ");						// Append each element to the string
			}
			s.append("\n");
		}
		return s.toString();											// Return the string representation of the adjacency matrix
	}
}