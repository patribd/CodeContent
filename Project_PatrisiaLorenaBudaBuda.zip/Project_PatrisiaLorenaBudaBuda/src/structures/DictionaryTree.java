package structures;

//A binary search tree implementation for storing key-value pairs
public class DictionaryTree<K extends Comparable<K>, V> {
 private class TreeNode {                                                            // Nested class to represent a node in the binary search tree
     private DictionaryPair value;                                                   // The key-value pair stored in this node
     private TreeNode leftNode;                                                      // Reference to the left subtree
     private TreeNode rightNode;                                                     // Reference to the right subtree

     public TreeNode(DictionaryPair pair) {                                          // Constructor to initialize a TreeNode with a key-value pair
         this.value = pair;
         this.leftNode = null;
         this.rightNode = null;
     }

     public TreeNode getLeftTree() {
         return leftNode;                                                            // Getter for the left subtree
     }

     public TreeNode getRightTree() {
         return rightNode;                                                           // Getter for the right subtree
     }

     public DictionaryPair getValue() {
         return value;                                                               // Getter for the key-value pair stored in this node
     }
 }

 private class DictionaryPair implements Comparable<DictionaryPair> {                // Nested class to represent a key-value pair
     private K key;                                                                  // The key of the pair
     private V value;                                                                // The value of the pair

     public DictionaryPair(K key, V value) {                                         // Constructor to initialize a key-value pair
         this.key = key;
         this.value = value;
     }

     public K getKey() {
         return key;                                                                 // Getter for the key
     }

     public V getValue() {
         return value;                                                               // Getter for the value
     }

     @Override
     public int compareTo(DictionaryPair other) {
         return key.compareTo(other.key);                                            // Compare two DictionaryPairs based on their keys
     }

     @Override
     public String toString() {
         return key + "=" + value;                                                   // Return a string representation of the key-value pair
     }
 }

 private TreeNode root;                                                              // The root node of the binary search tree

 public DictionaryTree() {
     root = null;                                                                    // Constructor to initialize an empty binary search tree
 }

 public void add(K key, V value) {                                                   // Add a key-value pair to the binary search tree
     DictionaryPair pair = new DictionaryPair(key, value);
     root = insertAtNode(pair, root);                                                // Call helper method to insert the pair
 }

 private TreeNode insertAtNode(DictionaryPair pair, TreeNode current) {              // Recursive helper method to insert a key-value pair into the tree
     if (current == null) {
         return new TreeNode(pair);                                                  // Create a new node if the position is empty
     }
     int comparison = pair.compareTo(current.getValue());
     if (comparison < 0) {
         current.leftNode = insertAtNode(pair, current.getLeftTree());               // Go to left subtree
     } else if (comparison > 0) {
         current.rightNode = insertAtNode(pair, current.getRightTree());             // Go to right subtree
     } else {
         current.getValue().value = pair.value;                                      // Update value if key exists
     }
     return current;
 }

 public DictionaryPair find(DictionaryPair pair) {                                   // Find a key-value pair in the tree
     K keyToFind = pair.key;                                                         // Extract the key from the provided pair
     TreeNode foundNode = findNode(keyToFind, root);                                 // Call the findNode method to locate the node containing the key

     if (foundNode != null) {
         return foundNode.getValue();                                                // Return the value (DictionaryPair) stored in the found node
     } else {
         return null;                                                                // Return null if no matching node was found
     }
 }


 private TreeNode findNode(K key, TreeNode current) {                                // Recursive helper method to find a node by key
     if (current == null) {
         return null;                                                                // Key not found
     }
     int comparison = key.compareTo(current.getValue().key);
     if (comparison == 0) {
         return current;                                                             // Key found
     } else if (comparison < 0) {
         return findNode(key, current.getLeftTree());                                // Search left subtree
     } else {
         return findNode(key, current.getRightTree());                               // Search right subtree
     }
 }

 public void remove(K key) {                                                         // Remove a key-value pair from the tree
     root = removeAtNode(key, root);                                                 // Call helper method to remove the node
 }

 private TreeNode removeAtNode(K key, TreeNode current) {                            // Recursive helper method to remove a node by key
     if (current == null) {
         return null;                                                                // Key not found
     }
     int comparison = key.compareTo(current.getValue().key);
     if (comparison < 0) {
         current.leftNode = removeAtNode(key, current.getLeftTree());                // Go to left subtree
     } else if (comparison > 0) {
         current.rightNode = removeAtNode(key, current.getRightTree());              // Go to right subtree
     } else {
         																			 // Key found
         if (current.getLeftTree() == null && current.getRightTree() == null) {
             return null;                                                            // No children
         } else if (current.getLeftTree() == null) {
             return current.getRightTree();                                          // One child --> right
         } else if (current.getRightTree() == null) {
             return current.getLeftTree();                                           // One child --> left
         } else {
             // Two children--> find in-order successor
             TreeNode smallest = findSmallest(current.getRightTree());
             current.value = smallest.getValue();
             current.rightNode = removeAtNode(smallest.getValue().key, current.getRightTree());
         }
     }
     return current;
 }

 private TreeNode findSmallest(TreeNode current) {                                    // Helper method to find the smallest node in a subtree
     while (current.getLeftTree() != null) {
         current = current.getLeftTree();
     }
     return current;
 }

 public void traverseInOrder(TraversalAction<K, V> action) {
	    traverseInOrder(root, action); 
	}

	private void traverseInOrder(TreeNode current, TraversalAction<K, V> action) {
	    if (current != null) {
	        traverseInOrder(current.getLeftTree(), action);
	        action.perform(current.getValue().getKey(), current.getValue().getValue());
	        traverseInOrder(current.getRightTree(), action);
	    }
	}

 public V getValueForKey(K key) {                                                    // Get the value associated with a given key
     DictionaryPair searchPair = new DictionaryPair(key, null);                      // Create a temporary DictionaryPair with the key and a null value
     DictionaryPair foundPair = find(searchPair);                                    // Find the matching pair in the tree

     if (foundPair != null) {
         return foundPair.getValue();                                                // Return the value associated with the key
     } else {
         return null;                                                                // Return null if no pair was found
     }
 }

 @Override
 public String toString() {
     StringBuilder sb = new StringBuilder("{");
     traverseInOrder((key, value) -> {
         if (sb.length() > 1) sb.append(", ");
         sb.append(key).append("=").append(value);
     });
     sb.append("}");
     return sb.toString();
 }

 public interface TraversalAction<K, V> {
     void perform(K key, V value); 													// Interface for defining actions to perform during traversal
 }
}
