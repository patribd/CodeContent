package structures;

public class Stack<T extends Comparable<T>> {

	/*
	// Implementation using vectors ---------------------------------------------------------------------------------------

	private Vector<T> data;					// A vector to hold the elements of the stack

	public Stack() {						// Constructor: Initializes the stack with an initial capacity of 100
		data = new Vector<>(100);
	}


	public void push(T newElement) { 		// Pushes an element onto the stack
		data.addLast(newElement);			// Using the addLast method of the vector to add the new element at the end (top of the stack)
    }


	public Object pop() { 					// Removes and returns the top element of the stack
		if (data.isEmpty()){
			return null;					// If the stack is empty, return null
		}else{
			T lastElement = data.getLast(); // Retrieve the last element (top of the stack)
			data.removeLast();				// Removing the last element of the stack
			return lastElement;				// Return the removed element
		}
	}

	public Object top() {					// Retrieves the top element of the stack without removing it
		return data.getLast();				// Get the last element of the stack (top of the stack) without removing it
	}

	public int size() {						// Returns the number of elements in the stack
		return data.size();					// Using the same method than in the vectors to obtain the size
	}

	public boolean empty() {				// Checks whether the stack is empty
		return data.isEmpty();				// Use the isEmpty method of the vector to check if the stack has no elements
	}

	 */

    // Implementation using linked lists ---------------------------------------------------------------------------------------

    private LinkedList<T> data;				// A linked list to hold the elements of the stack

    public Stack(){
        data = new LinkedList<>();			// Constructor: Initializes the stack as an empty linked list
    }

    public void push(T newElement){			// Pushes an element onto the stack
        data.addFirst(newElement);			// Adds the element to the front of the linked list (top of the stack)
    }

    public T pop(){							// Removes and returns the top element of the stack --> LIFO
        if (data.isEmpty()){
            return null;					// If the stack is empty, return null
        }else{
            T topElement = data.getFirst();	// Retrieve the first element (top of the stack)
            data.removeFirst();				// Remove the first element from the stack
            return topElement;				// Return the removed element
        }
    }

    public T top(){							// Retrieves the top element of the stack without removing it
        return data.getFirst();				// Return the first element (top of the stack) without removing it
    }

    public int size(){						// Returns the number of elements in the stack
        return data.size();					// Use the size method of the linked list to determine the number of elements
    }

    public boolean empty(){					// Checks whether the stack is empty
        return data.isEmpty();				// Use the isEmpty method of the linked list to check if the stack has no elements
    }

    public String toString() {
        return "Stack: " + data.toString(); // Uses the toString method of the linked list to represent stack elements
    }

}