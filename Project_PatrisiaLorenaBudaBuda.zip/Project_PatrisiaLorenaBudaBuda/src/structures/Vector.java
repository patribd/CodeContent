package structures;

public class Vector<T extends Comparable<T>> implements Comparable<Vector<T>> {
	private Comparable[] data;													// Array to store elements
	private int capacity;														// Current capacity of the vector
	private int count;															// Number of elements currently in the vector


	public Vector(int capacity)													// Constructor to initialize vector with a specified capacity
	{
		this.capacity = capacity;
		this.data = new Comparable[capacity];									// Initializing the array used to compute the methods
		this.count = 0;															// Starting with an empty vector
	}

	public int size()
	{
		return count;															// Returns the number of elements in the vector
	}

	public boolean isEmpty()
	{
		return size() == 0;														// Checks if the vector is empty --> no elements in the vector
	}

	public T get(int index)														// Gets the element at a specific index
	{
		if (index >= 0 && index < count){
			return (T) data[index];												// Return the specific element if the index is valid
		}else{
			return null;														// Return null for an invalid index
		}
	}

	public void set(int index, T element)										// Sets the element at a specific index
	{
		if (index >= 0 && index < count){
			data[index] = element;												// Replace the element at the given index
		}
	}

	public boolean contains(T element) 											// Checks if the vector contains a specific element
	{
		for(int i=0;i<count;i++)
		{
			if(data[i] == element) return true;									// Return true if the element is found
		}
		return false;															// Return false if not found
	}

	/*
	 * CODE USEFULL WHEN NO MORE CAPACITY IS NEEDED
	public void addFirst(T element)												// Adds an element to the front of the vector
	{
		for (int i = count - 1; i >= 0; i--){
			data[i+1] = data[i]; 												// Shift all the elements to the right
		}
		data[0] = element;														// Insert the new element at the front
		count++;
	}

	public void addLast(T element)												// Adds an element to the end of the vector
	{
		data[count] = element;													// Add the new element at the end
		count++;
	}
	 */

	public void addFirst(T newElement)											// Method to add an element at the front of the vector
	{
		if (count == capacity){													// Extends capacity if the vector is full before adding the element
			extendCapacity();
		}
		for (int i = count - 1; i >= 0; i--){
			data[i+1] = data[i];												// Shift all the elements to the right
		}
		data[0] = newElement;													// Insert the new element at the front
		count++;
	}

	public void addLast(T newElement)											// Method to add an element to the end of the vector
	{
		if (count == capacity){													// Extend capacity if the vector is full
			extendCapacity();
		}
		data[count] = newElement;												// Add the new element at the end
		count++;
	}


	public boolean binarySearch(T key) {
		int startPoint = 0;														// Index of the first position of the vector
		int endPoint = count - 1;												// Index of the last position of the vector

		while (startPoint <= endPoint) {
			int middle = (startPoint + endPoint) / 2; 							// Find the middle index

			Comparable<T> middleElement = (Comparable<T>) data[middle]; 		// Cast elements to Comparable and compare them with the key

			if (middleElement.compareTo(key) > 0) {								// The value is smaller
				endPoint = middle - 1; 											// Search in the left half
			} else if (middleElement.compareTo(key) < 0) {						// The value is greater
				startPoint = middle + 1; 										// Search in the right half
			} else {
				return true; 													// Element was found
			}
		}

		return false; 															// Element was not found
	}


	public T getFirst() 														// Method to return the first element in the vector
	{
		return isEmpty() ? null : (T) data[0];									// If the vector is not empty, we return the element on first position (index = 0)
	}

	public T getLast()															// Returns the last element in the vector
	{
		if (!isEmpty()) {
			return (T) data[count - 1];											// If the vector is not empty, we return the element on the last position
		}
		return null;
	}

	public void removeFirst()													// Removes the first element in the vector
	{
		if (isEmpty()) return;													// If the list is empty we do not have to eliminate anything
		for (int i = 1; i< count; i++){
			data[i-1] = data[i];
		}
		data[count - 1] = null;													// Nullify the last element --> it is now in its position - 1
		count--;
	}

	public void removeLast()													// Removes the last element in the vector
	{
		if (isEmpty()) return;													// If the list is empty we do not have to eliminate anything
		data[count-1] = null;													// Nullify the last element
		count--;
	}


	public String toString()													// Converts the vector to a string representation
	{
		String vectorAsAString = "[";											// Beginning of the string
		for (int i = 0; i < count; i++) {
			if (data[i] != null) {
				vectorAsAString += " " + data[i].toString();					// Convert each element into string representation
			}
		}
		vectorAsAString += "]";													// End of the string

		return vectorAsAString;
	}


	public void reverse(){														// Reverses the elements in the vector
		for (int i = count - 1; i >= count / 2; i--){
			T originalValue = (T) data[count-i-1];								// Temporary variable for swapping --> out-of-place method
			data[count-i-1]=data[i];
			data[i]=originalValue;
		}
	}

	public Vector<T> repeat(){													// Creates a new vector by repeating elements of the current vector
		Vector<T> v2 = new Vector<>(count * 2);									// Creating empty vector with double size
		for (int i=0 ; i < count ; i++){
			v2.addLast((T) data[i]);
			v2.addLast((T) data[i]);
		}
		return v2;
	}

	public Vector<T> interleave(Vector v2){										// Interleaves elements of the current vector with another vector
		Vector<T> finalVector = new Vector<>(count * 2);						// Creating empty vector with double capacity
		for (int i=0 ; i < count ; i++){
			finalVector.addLast((T) data[i]);									// Get element from one vector (v1)
			finalVector.addLast((T) v2.get(i));									// Get the other element from the second vector (v2) to interleave both
		}
		return finalVector;
	}

	private void extendCapacity(){												// Extends the capacity of the vector when full
		if (count == capacity) {
			capacity *= 2;														// Double the capacity when full --> it needs to change in the entire code
			Comparable[] newData = new Comparable[capacity];					// Creating new empty vector with the new capacity
			for (int i = 0; i < count; i++) {
				newData[i] = data[i];											// Copying the data to the new doubled capacity vector
			}
			data = newData;
		}
	}

	public T find(T key) {														// Method to find and return an element in the vector that matches the given key --> graphs
		for (int i = 0; i < count; i++) {										// Iterate through all elements in the vector
			if (data[i].equals(key)) {
				return (T) data[i];												// Return the matching element
			}
		}
		return null; // Not found
	}

	@Override
	public int compareTo(Vector<T> other) {										// Method to compare this vector with another vector
		if (this.size() < other.size()) {										// Compare the sizes of the two vectors
			return -1;															// This vector is smaller
		} else if (this.size() > other.size()) {
			return 1;															// This vector is larger
		}

		for (int i = 0; i < this.size(); i++) {									// If sizes are equal, compare element by element
			int comparison = this.get(i).compareTo(other.get(i));				// Compare the current elements from both vectors
			if (comparison != 0) {
				return comparison;												// Return the result of the first non-equal comparison
			}
		}
		return 0;																// Return 0 if all elements are equal and the sizes are the same
	}
}