package structures;

public class Matrix 
{
	private Comparable[][] matrix; 																						// Private member to store the matrix
	
	public Matrix(int numberNodes) 																						// Constructor to alocate the N-by-N matrix
	{
		matrix = new Comparable[numberNodes][numberNodes];																// Intializing the matrix
		for (int i = 0; i < numberNodes ; i++){
			for (int j = 0; j < numberNodes; j++){
				matrix[i][j] = 0;																						// Initializing all the elements to zero
			}
		}
	}
	
	public void set(int row, int column, Comparable weight)
	{
		if (row >= 0 && row < matrix.length && column >= 0 && column < matrix[row].length){ 							// Check if the row and column introduce make sense
			matrix[row][column] = weight; 																				// Specify the weight
		}else {
			throw new IndexOutOfBoundsException("The index of the row or column is out of bounds. Try again."); 		// The row or the column introduce do not correspond to this matrix
		}
	}

	public Comparable get(int row, int column)
	{
		if (row >= 0 && row < matrix.length && column >= 0 && column < matrix[row].length){ 							// Check if the row and column introduce make sense
			return matrix[row][column]; 																				// Return the weight
		}else {
			throw new IndexOutOfBoundsException("The index of the row or column is out of bounds. Try again."); 		// The row or the column introduce do not correspond to this matrix
		}
	}

	public Comparable[][] getMatrix() {																					// Add this getter method to expose the matrix
		return matrix;																									// Return the 2D array representing the matrix
	}
}