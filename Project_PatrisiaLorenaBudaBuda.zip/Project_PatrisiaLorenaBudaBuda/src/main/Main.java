package main;

import structures.*;
import representers.*;


/*
 * My name is Patrisia Lorena Buda Buda and I decided to use DictionaryTree, Vector, and Graph as the core data structures for implementing this part of the project. 
 * These data structures were selected because they directly best address the requirements for efficient storage, retrieval, and traversal of: users, jobs, and locations.
 * 
 * The DictionaryTree was used to store and retrieve User and Job objects using unique IDs as keys. It allows efficient lookups, in-order traversal,
 * and maintains an ordered structure, which simplifies operations like printing all users and jobs in a sorted manner.
 * 
 * The Vector structure (which was determined by the interface) was used to dynamically store and manage collections such as available jobs and directions. 
 * It is chosen for its dynamic resizing capabilities and efficient sequential access, which were crucial for storing paths and filtering available jobs.
 * 
 * The Graph structure was implemented to represent streets and connections between them. This graph supports operations like adding nodes (streets), 
 * connecting streets with weights (distances), and finding the shortest path between two nodes using BFS. The BFS algorithm (studied in class) was specifically chosen 
 * as it is simple, efficient, and well-suited for unweighted or uniformly weighted graphs.
 * 
 * Specific implementations like DictionaryTree and Vector were used since they were modified to fit the specific needs of the project. Additionally, I modified the graph to ensure it could 
 * integrate easily with other parts of the system: finding directions for users to their applied jobs.
 * 
 * LinkedLists were used internally within some data structures, such as the Graph's node-edge relationships (recommended in the manual), due to their efficient sequential access and 
 * ease of insertion. However, they were not used for general collections like available jobs due to their lack of efficient index-based access.
 * 
 * To sum up, the combination of DictionaryTree, Vector, and Graph provided a robust and flexible foundation for managing the relationships between users, 
 * jobs, and streets. The system is efficient, extensible, and prepared to accommodate the upcoming requirements for the next phase of the project.
 */


public class Main {
    public static void main(String[] args) {
    	// I CREATED THIS MAIN PROGRAM TO CHECK THE FUNCTIONALITY OF THE PROJECT
    	
    	// Create an instance of the NeighbourHelper
        NeighbourHelper helper = new NeighbourHelper();

        // Adding Users
        int user1ID = helper.addUser("Patrisia Buda", "patrisia@gmail.com", "Calle Roncal");
        int user2ID = helper.addUser("Mirela Martinez", "mirela@gmail.com", "Sancho III");
        int user3ID = helper.addUser("Alicia Diaz", "alicia@gmail.com", "Avenida de Navarra");

        // Print all users
        System.out.println("All the users that we have are: ");
        helper.printAllUsers();

        // Adding Jobs
        int job1ID = helper.addJob("Fix Door", "Fix the noise of the door", "Repair", true, 50.0f, user1ID);
        int job2ID = helper.addJob("Clean the kitchen", "Clean the dirtiness of the kitchen", "General House Work", false, 0.0f, user2ID);
        int job3ID = helper.addJob("Cut the grass", "Cut the grass from the front garden", "Outside Work", true, 35.0f, user3ID);

        // Print all jobs
        System.out.println("\nAll the jobs that we have are :");
        helper.printAllJobs();

        // Find a specific user and job
        System.out.println("\nFind Specific User and Job: ");
        System.out.println("The user with ID " + user1ID + " is: " + helper.findUser(user1ID));
        System.out.println("The job with ID " + job1ID + " is: " + helper.findJob(job1ID));

        // Find all available jobs
        System.out.println("\nThe available jobs are: ");
        Vector<Job> availableJobs = helper.findAvailableJobs();
        for (int i = 0; i < availableJobs.size(); i++) {
            System.out.println(availableJobs.get(i));
        }

        // Find available jobs in a specific category
        System.out.println("\nThe available jobs in category 'Repair': ");
        Vector<Job> repairJobs = helper.findAvailableJobsInCategory("Repair");
        for (int i = 0; i < repairJobs.size(); i++) {
            System.out.println(repairJobs.get(i));
        }
        
        // Apply for a job
        System.out.println("\nIf someone applies for a job: ");
        boolean applied = helper.applyForJob(user1ID, job1ID);
        helper.applyForJob(user2ID, job2ID);
        helper.applyForJob(user3ID, job3ID); 
        System.out.println("User with ID " + user1ID + " applied for job: " + applied);

        // Print updated jobs
        System.out.println("\nThe updated jobs after the application are: ");
        helper.printAllJobs();

        // Add streets and connect them
        System.out.println("\nStreets and Connections: ");
        helper.addStreet("Calle Roncal");
        helper.addStreet("Sancho III");
        helper.addStreet("Avenida de Navarra");
        helper.connectStreets("Calle Roncal", "Sancho IIIe", 5);
        helper.connectStreets("Sancho III", "Avenida de Navarra", 10);
        helper.connectStreets("Avenida de Navarra", "Calle Roncal", 15);

        
        
        // Get directions for a specific user
        System.out.println("\nDirections for User " + user1ID + " :");
        System.out.println(helper.getDirections(user1ID));
        System.out.println("\nDirections for User " + user2ID + " :");
        System.out.println(helper.getDirections(user2ID));
        System.out.println("\nDirections for User " + user3ID + " :");
        System.out.println(helper.getDirections(user3ID));
    }
}
