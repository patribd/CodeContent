package main;

import representers.*;
import structures.*;

public class NeighbourHelper implements iNeighbourHelper {
	
	// DictionaryTree to store users, which are keyed by their unique user IDs 
	// Why ? It offers an efficient key-based lookup and sorted traversal
    private DictionaryTree<Integer, User> users = new DictionaryTree<>();

    // DictionaryTree to store jobs, which are keyed by their unique job IDs
    // Why? It allows efficient retrieval of jobs by ID and ordered traversal
    private DictionaryTree<Integer, Job> jobs = new DictionaryTree<>();

    // DictionaryTree to map job IDs to their respective user IDs
    // Why? It provides a simple and efficient way to look up the owner of a job (I was missing this on the submission of Part 2)
    private DictionaryTree<Integer, Integer> jobToUserMap = new DictionaryTree<>(); 				

    // Graph to represent the streets and their connections.
    // Why? This is used to calculate the shortest path between locations using BFS
    private Graph<String> streetGraph = new Graph<>();


	@Override
	public int addUser(String name, String email, String street) {
		 User newUser = new User(name, email, street); 												// Create a new user
	        users.add(newUser.getUserID(), newUser); 												// Store the user in the DictionaryTree with their ID as the key
	        return newUser.getUserID();																// Return the ID of the newly added user
	}

	@Override
	public int addJob(String title, String description, String category, boolean isPaid, float price, int userID) {
		if (users.getValueForKey(userID) == null) { 												// Check if the user exists
            throw new IllegalArgumentException("User with ID " + userID + " does not exist.");
        }
        Job newJob = new Job(title, description, category, isPaid, price); 							// Create a new job and add it to the DictionaryTree
        jobs.add(newJob.getJobId(), newJob); 														// Store the job in the DictionaryTree with its ID as the key
        jobToUserMap.add(newJob.getJobId(), userID); 												// Map the job ID to the user ID
 
        return newJob.getJobId();																	// Return the ID of the newly added job
	}

	@Override
	public void printAllUsers() {
		 users.traverseInOrder((key, value) -> System.out.println(value));							// Traverse the DictionaryTree in order and print each user
		
	}

	@Override
	public void printAllJobs() {
		jobs.traverseInOrder((key, value) -> System.out.println(value));							// Traverse the DictionaryTree in order and print each job
		
	}

	@Override
	public User findUser(int userID) {
		 return users.getValueForKey(userID);														// Retrieve and return the user by their ID
	}

	@Override
	public Job findJob(int jobID) {
		return jobs.getValueForKey(jobID);															// Retrieve and return the job by its ID
	}

	@Override
	public Vector findAvailableJobs() {
		Vector<Job> availableJobs = new Vector<>(10);												// Initialize a vector to store available jobs
        jobs.traverseInOrder((key, value) -> { 														// Traverse the jobs DictionaryTree and add available jobs to the vector
            if (value.isAvailable()) {
                availableJobs.addLast(value);
            }
        });
        return availableJobs;																		// Return the vector of available jobs
	}

	@Override
    public Vector<Job> findAvailableJobsInCategory(String category) {
		Vector<Job> categoryJobs = new Vector<>(10);												// Initialize a vector for category-specific jobs
        jobs.traverseInOrder((key, value) -> {														// Traverse the jobs DictionaryTree and filter jobs by category and availability
            if (value.isAvailable() && value.getCategory().equalsIgnoreCase(category)) {
                categoryJobs.addLast(value);
            }
        });
        return categoryJobs;																		// Return the filtered jobs
    }

	@Override
	public boolean removeJob(int jobID) {
		if (jobs.getValueForKey(jobID) != null) { 													// Check if the job exists
            jobs.remove(jobID); 																	// Remove the job
            jobToUserMap.remove(jobID); 															// Remove the mapping as well
            return true;
        }
        return false;																				// Return false if the job does not exist
	}

	@Override
	public boolean applyForJob(int userID, int jobID) {
		// Check if the user and job exist, and the job is available
	    User user = findUser(userID);
	    Job job = findJob(jobID);

	    if (user != null && job != null && job.isAvailable()) {
	        job.markAsUnavailable(); 																// Mark the job as unavailable once someone has applied to it
	        return true;
	    }
	    return false;																				// Return false if the application is unsuccessful
	}

	@Override
	public void addStreet(String street) {
		streetGraph.addNode(street); 																// Add the street as a node in the graph.
		System.out.println("Street added: " + street);
	}

	@Override
	public void connectStreets(String street1, String street2, int distance) {
		 streetGraph.addEdge(street1, street2, distance); 											// Add an edge from street1 to street2.
	     streetGraph.addEdge(street2, street1, distance); 											// Add an edge from street2 to street1 for undirected graph.
	     System.out.println("Connected " + street1 + " to " + street2 + " with distance " + distance);
	}

	@Override
	public Vector<String> getDirections(int userID) {
	    User user = findUser(userID);																// Retrieve the user by ID
	    if (user == null) {
	        throw new IllegalArgumentException("The user with ID " + userID + " does not exist.");
	    }

	    String userStreet = user.getStreet();														// Get the user's home street
	   
	    Vector<String> jobStreets = new Vector<>(10);												// Store the streets of job owners
	    jobs.traverseInOrder((jobID, job) -> { 														// Traverse the jobs to find streets of job owners for unavailable jobs
	     
	        if (!job.isAvailable()) {
	            int ownerID = jobToUserMap.getValueForKey(jobID);
	           
	            User jobOwner = users.getValueForKey(ownerID);
	            if (jobOwner != null) {
	               
	                jobStreets.addLast(jobOwner.getStreet());
	            }
	        }
	    });

	    Vector<String> directions = new Vector<>(10); 												// Store the shortest paths
	    for (int i = 0; i < jobStreets.size(); i++) {
	        String jobStreet = jobStreets.get(i);
	        LinkedList<String> path = streetGraph.bfsShortestPath(userStreet, jobStreet);

	        if (path != null) {
	            for (int j = 0; j < path.size(); j++) {
	                String street = path.get(j);

	                // Check if the street is already in "directions"
	                boolean alreadyExists = false;
	                for (int k = 0; k < directions.size(); k++) {
	                    if (directions.get(k).equals(street)) {
	                        alreadyExists = true;
	                        break;
	                    }
	                }

	                // Add the street only if it doesn't already exist to avoid cyclic circles
	                if (!alreadyExists) {
	                    directions.addLast(street);
	                }
	            }
	        }
	    }

	    return directions;																			// Return the vector of directions
	}


}
